import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {mkdir,writeFile,readFile} from 'node:fs/promises';
import path from 'node:path';
import {capture,sameInputs,save,runtime,root,digest} from './src/manifest.mjs';
const exec=promisify(execFile),runId=new Date().toISOString().replaceAll(/[:.]/g,'-'),dir=path.join(runtime,'results',runId);
await mkdir(dir,{recursive:true});
const before=await capture(),beforeRef=await save(dir,'manifest-before.json',before);
const commands=[];
for(const args of [
 [path.join(root,'node_modules/typescript/bin/tsc'),'--noEmit','--strict','--skipLibCheck','--target','es2022','--module','nodenext','--moduleResolution','nodenext',path.join(runtime,'src/toolchain.ts')],
 [path.join(runtime,'src/toolchain.ts')],
 ['--test','--test-concurrency=1','--test-reporter=tap','test/manifest.test.mjs','test/http.test.mjs','test/db.test.mjs','test/session.test.mjs','test/restart.test.mjs']
]){
 let stdout='',stderr='',exitCode=0;try{({stdout,stderr}=await exec(process.execPath,args,{cwd:runtime,timeout:120000,maxBuffer:2000000}));}catch(e){stdout=e.stdout??'';stderr=e.stderr??'';exitCode=e.code??1;}
 const log=await save(dir,`command-${commands.length+1}.json`,{command:[process.execPath,...args],exitCode,stdout,stderr});commands.push({args,exitCode,log,stdout});
}
const after=await capture(),afterRef=await save(dir,'manifest-after.json',after),stable=sameInputs(before,after);
const tap=commands.at(-1).stdout;
const ledger=[];
for(const [group,count] of [['HTTP',13],['DB',11],['SESSION',14]])for(let i=1;i<=count;i++){
 const id=`E-${group}-${String(i).padStart(2,'0')}`;
 const matching=tap.split('\n').filter(line=>new RegExp(`^\\s*(?:not )?ok \\d+ - ${id}\\b`).test(line));
 const failed=matching.some(line=>line.trim().startsWith('not ok'));
 ledger.push({id,applicability:'required unless explicitly optional below',state:matching.length?(failed?'Run-failed':'Run-passed'):'Not run',source:`test/${group==='HTTP'?'http':group==='DB'?'db':'session'}.test.mjs`,subAssertions:matching,limits:[]});
}
const by=id=>ledger.find(row=>row.id===id);
for(const id of ['E-DB-05','E-DB-10','E-SESSION-14']){Object.assign(by(id),{applicability:'Optional comparison / unresolved catalogue or owner policy',state:'Not run',limits:['No disabled-account or separate failed-login auditing policy adopted by this spike. TC-01 locked-credential coverage remains required for application acceptance.']});}
by('E-SESSION-11').source='test/http.test.mjs';
Object.assign(by('E-SESSION-12'),{state:'Run-failed',sources:['test/session.test.mjs','test/restart.test.mjs'],limits:['Baseline negative control observed revival after backward injected repository time, including new repository instance. Guarded variant persistently latches an observed regression and denies issuance/renewal across repository reconstruction and real PostgreSQL restart. Recovery audit rollback and old-token denial survived a second real restart. Unobserved elapsed-time/backstep intervals cannot be detected by this mitigation. Real DB clock sanity passed; host clock was not modified. Precision extremes and independently verified operator time remain outside this experiment.']});
by('E-HTTP-01').limits.push('TypeScript compile/direct-TS startup are separately executed; JavaScript HTTP fixture is not a TypeScript application adapter.');
by('E-HTTP-02').schemaCaseMap={validLogin:'E-HTTP-02 valid seeded login',actorExtra:'E-HTTP-02 and E-HTTP-04',emailAlias:'E-HTTP-02 and E-HTTP-03',emptyUsername:'E-HTTP-06',missingPassword:'E-HTTP-02',validSession:'E-HTTP-02',malformedExpiry:'E-HTTP-02 malformed output',extraToken:'E-HTTP-07'};
by('E-HTTP-06').limits.push('Exact body-limit boundary exercised. No independent KDF input maximum selected; production credential input policy remains open.');
by('E-HTTP-09').limits.push('HTTPS header evidence only; browser Secure-cookie storage/send semantics not run.');
by('E-HTTP-10').limits.push('POST and DELETE policy exercised; production policy remains owner-selected.');
by('E-DB-03').limits.push('HTTP fixture invokes the actual failing pg transaction and emits no successful cookie; illustrative audit is not catalogue adoption.');
by('E-DB-09').limits.push('Real probe backend termination and injected receipt loss after actual COMMIT tested. The receipt hook simulates caller uncertainty; no actual TCP acknowledgement drop or whole-container failure was injected.');
const result={runId,createdAt:new Date().toISOString(),inputStable:stable,before:beforeRef,after:afterRef,commands:commands.map(({stdout,...c})=>c),applicationHandlerBehavioursVerified:0,scope:'Laboratory adapters and disposable DB only',ownerSelection:null,review:'Not requested; author self-check only',clock:{strategy:'DB clock_timestamp sampled after FOR UPDATE; test seam after same lock',syntheticLimits:{idleSeconds:60,absoluteSeconds:300},knownFailure:'Backstep revival remains unresolved'},ledger};
await save(dir,'result.json',result);
await writeFile(path.join(dir,'report.md'),`# SP-01 runtime spike ${runId}\n\nApplication handler behaviours verified: **0**.\n\nInput hashes stable: ${stable}. Command exit codes: ${commands.map(c=>c.exitCode).join(', ')}.\n\nKnown failure: backward clock can revive an expired session after repository restart. Full experiments with unexecuted subcases remain Not run; see result.json and TAP logs. No production policy is selected.\n`);
const receipt={};for(const name of ['result.json','report.md'])receipt[name]=digest(await readFile(path.join(dir,name)));await save(dir,'receipt.json',receipt);
console.log(JSON.stringify({runId,dir,stable,exitCodes:commands.map(c=>c.exitCode),states:ledger.reduce((out,r)=>(out[r.state]=(out[r.state]??0)+1,out),{})}));
if(!stable||commands.some(c=>c.exitCode!==0))process.exitCode=1;
