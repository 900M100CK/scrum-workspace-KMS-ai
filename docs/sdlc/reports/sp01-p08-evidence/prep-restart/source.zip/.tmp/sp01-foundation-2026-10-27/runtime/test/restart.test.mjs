import test from 'node:test';
import assert from 'node:assert/strict';
import {database,digestToken} from '../src/database.mjs';
import {Repository} from '../src/session.mjs';

test('E-SESSION-12 real PostgreSQL restart retains fault and recovery revokes pre-restart tokens',{timeout:90000},async t=>{
 const db=await database({persistent:true});t.after(()=>db.close());let now=2000000000000;
 const original=new Repository(db.pool,{clock:()=>now,guard:true});
 const token=await original.create();const start=(await db.pool.query('select pg_postmaster_start_time()::text started')).rows[0].started;
 now-=1;assert.equal((await original.act(token,{renew:true})).status,503);
 const faultBefore=(await db.pool.query('select healthy,last_observed::text from probe_clock_guard')).rows[0];
 await db.restart();
 const after=(await db.pool.query('select pg_postmaster_start_time()::text started')).rows[0].started;assert.notEqual(after,start);
 const faultAfter=(await db.pool.query('select healthy,last_observed::text from probe_clock_guard')).rows[0];assert.deepEqual(faultAfter,faultBefore);
 const restarted=new Repository(db.pool,{clock:()=>now,guard:true});assert.equal((await restarted.act(token)).status,503);await assert.rejects(restarted.create(),/issuance withheld/);
 const expectedLast=(await db.pool.query('select last_observed from probe_clock_guard')).rows[0].last_observed.getTime();
 await assert.rejects(restarted.recoverClock({expectedLast:expectedLast+1,attestedTime:now,evidenceId:'synthetic-restart-attestation'}),/Stale/);
 await assert.rejects(restarted.recoverClock({expectedLast,attestedTime:now,evidenceId:'synthetic-restart-attestation',auditFail:true}),{code:'23514'});
 assert.equal((await db.pool.query('select healthy from probe_clock_guard')).rows[0].healthy,false);
 assert.equal((await db.pool.query('select revoked_at from probe_session where digest=$1',[digestToken(token)])).rows[0].revoked_at,null);
 await restarted.recoverClock({expectedLast,attestedTime:now,evidenceId:'synthetic-restart-attestation'});
 assert.equal((await restarted.act(token)).status,401);assert.equal((await restarted.act(await restarted.create())).status,200);
 await db.restart();const recovered=new Repository(db.pool,{clock:()=>now,guard:true});assert.equal((await recovered.act(token)).status,401);
 assert.equal((await db.pool.query('select count(*) from probe_audit where detail=$1',['clock-recovery:synthetic-restart-attestation'])).rows[0].count,'1');
 t.diagnostic(JSON.stringify({container:db.name,volume:db.volume,image:db.image,version:db.version,postmasterBefore:start,postmasterAfter:after,observed:{faultSurvived:true,auditRollback:true,oldTokenDeniedAfterRecoveryAndSecondRestart:true},clock:'injected repository time after locks; real PostgreSQL restarts'}));
});
