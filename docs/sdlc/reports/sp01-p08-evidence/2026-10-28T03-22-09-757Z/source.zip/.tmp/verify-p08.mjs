import {readFile,writeFile,mkdir,readdir} from 'node:fs/promises';
import {execFile,execFileSync} from 'node:child_process';
import {promisify} from 'node:util';
import {createHash} from 'node:crypto';
import path from 'node:path';
const exec=promisify(execFile),root=process.cwd(),runId=new Date().toISOString().replaceAll(/[:.]/g,'-'),dir=path.join(root,'docs/sdlc/reports/sp01-p08-evidence',runId);
const hash=x=>createHash('sha256').update(x).digest('hex');
const files=['package.json','package-lock.json','tsconfig.base.json','infra/postgres/bootstrap.sh','infra/postgres/bootstrap.sql','.tmp/verify-p08.mjs'];
async function sourceTree(dir){for(const entry of await readdir(dir,{withFileTypes:true})){const file=path.join(dir,entry.name).replaceAll('\\','/');if(entry.isDirectory())await sourceTree(file);else if(/\.(ts|mjs|json|sql)$/.test(file))files.push(file);}}
for(const dir of ['services/workspace/src','services/workspace/test','services/workspace/migrations','services/knowledge/src','services/knowledge/test','services/knowledge/migrations','apps/web/src','apps/web/dev','apps/web/test','scripts','tests'])await sourceTree(dir);
for(const pkg of ['services/workspace','services/knowledge','apps/web'])for(const name of ['package.json','tsconfig.json'])files.push(`${pkg}/${name}`);
files.push('services/workspace/tsconfig.build.json','services/knowledge/tsconfig.build.json','apps/web/vite.config.ts');
for(const name of ['workspace','knowledge'])files.push(`contracts/openapi/${name}.openapi.json`);
const inputs=[...new Set(files)].sort();
async function snapshot(){const hashes={};for(const file of inputs)hashes[file]=hash(await readFile(file));return {head:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),branch:execFileSync('git',['branch','--show-current'],{encoding:'utf8'}).trim(),scopedDiffSha256:hash(execFileSync('git',['diff','--binary','HEAD','--',...inputs],{maxBuffer:4*1024*1024})),files:hashes,node:process.version,versions:process.versions,scope:'Runnable source/test/SQL/package inputs only; documentation checks are recorded separately'};}
await mkdir(dir,{recursive:true});const before=await snapshot();await writeFile(path.join(dir,'manifest-before.json'),JSON.stringify(before,null,2)+'\n');
const commands=[];const npm='C:/Program Files/nodejs/node_modules/npm/bin/npm-cli.js';
const env={...process.env,PATH:path.dirname(process.execPath)+';'+process.env.PATH,SACW_DEV_TLS_KEY:path.join(root,'.tmp/local-https/localhost.key'),SACW_DEV_TLS_CERT:path.join(root,'.tmp/local-https/localhost.crt')};
const commandsToRun=process.argv.includes('--remaining')?['db:test','contracts:test'].map(name=>[npm,'run',name]):[[npm,'ci','--ignore-scripts','--offline','--no-audit','--no-fund'],...['typecheck','build','test:foundation','test:session:storage','db:test','contracts:test'].map(name=>[npm,'run',name])];
for(const args of commandsToRun){
 let stdout='',stderr='',exitCode=0;const started=new Date().toISOString();
 try{({stdout,stderr}=await exec(process.execPath,args,{cwd:root,env,timeout:300000,maxBuffer:4*1024*1024}));}catch(error){exitCode=error.code??1;stdout=error.stdout??'';stderr=error.stderr??'';}
 const name=`command-${commands.length+1}.json`,body={command:[process.execPath,...args],started,finished:new Date().toISOString(),exitCode,stdout,stderr};await writeFile(path.join(dir,name),JSON.stringify(body,null,2)+'\n');commands.push({name,exitCode,sha256:hash(await readFile(path.join(dir,name)))});
 console.log(JSON.stringify({command:args.slice(1).join(' '),exitCode}));
 if(exitCode!==0)break;
}
const after=await snapshot();await writeFile(path.join(dir,'manifest-after.json'),JSON.stringify(after,null,2)+'\n');
const stable=JSON.stringify(before.files)===JSON.stringify(after.files);const result={runId,inputStable:stable,commands,before:{path:'manifest-before.json',sha256:hash(await readFile(path.join(dir,'manifest-before.json')))},after:{path:'manifest-after.json',sha256:hash(await readFile(path.join(dir,'manifest-after.json')))},scope:'P08 persistence/operator/owned SQL; no HTTP auth handlers or deployment KDF/time acceptance',review:'Author verification only',sources:inputs};
await writeFile(path.join(dir,'result.json'),JSON.stringify(result,null,2)+'\n');await writeFile(path.join(dir,'receipt.json'),JSON.stringify({resultSha256:hash(await readFile(path.join(dir,'result.json')))},null,2)+'\n');
console.log(JSON.stringify({runId,dir,inputStable:stable,exitCodes:commands.map(c=>c.exitCode)}));if(!stable||commands.some(c=>c.exitCode!==0))process.exitCode=1;
