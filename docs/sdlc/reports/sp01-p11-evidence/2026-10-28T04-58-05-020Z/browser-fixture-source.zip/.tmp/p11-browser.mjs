import {readFile} from 'node:fs/promises';
import {randomUUID} from 'node:crypto';
import {createInterface} from 'node:readline';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
import {sessionFixture} from '../tests/workspace/fixture.mjs';
import {buildApp} from '../services/workspace/src/app.ts';
import {WorkspaceSessionStore,WorkspaceSessionOperator} from '../services/workspace/src/session/store.ts';
import {ScryptVerifier} from '../services/workspace/src/session/kdf.ts';
const webRequire=createRequire(new URL('../apps/web/package.json',import.meta.url)),{createServer}=await import(pathToFileURL(webRequire.resolve('vite')).href);
const db=await sessionFixture(),operator=new WorkspaceSessionOperator(db.admin),user=randomUUID();
let backend,web,closing=false;
async function stop(){if(closing)return;closing=true;await web?.close();await backend?.close();await db.close();process.exit(0);}
process.on('SIGINT',()=>void stop());process.on('SIGTERM',()=>void stop());
try{
 await operator.provision(user,'synthetic-browser',await new ScryptVerifier().hash('synthetic-P11-browser-only'),'synthetic-browser-operator');
 const s=await operator.state();await operator.recover({expectedGeneration:s.generation,expectedLastObserved:s.last_observed,attestedTime:new Date().toISOString(),maxSkewMs:5000,evidenceId:'synthetic-browser-time',operatorRef:'synthetic-browser-operator'});
 const origin='https://localhost:5181';backend=buildApp({store:new WorkspaceSessionStore(db.runtime,{idleSeconds:1800,absoluteSeconds:28800}),origin});await backend.listen({host:'127.0.0.1',port:0});
 web=await createServer({root:'apps/web',server:{host:'127.0.0.1',port:5181,strictPort:true,hmr:false,https:{key:await readFile('.tmp/local-https/localhost.key'),cert:await readFile('.tmp/local-https/localhost.crt')},proxy:{'^/api(?:/|$)':{target:`http://127.0.0.1:${backend.server.address().port}`}}}});await web.listen();
 console.log(JSON.stringify({ready:true,url:origin,container:db.name,scope:'Disposable browser fixture only'}));
 const lines=createInterface({input:process.stdin});lines.on('line',async command=>{
  try{
   if(command==='stop'){await stop();return;}
   if(command==='expire'){await db.admin.query("UPDATE workspace.session s SET expires_at=t.created_at+interval '1 microsecond' FROM workspace.session_token t WHERE s.session_id=t.session_id AND s.user_id=$1",[user]);console.log(JSON.stringify({expired:true}));}
   if(command==='disable'){await operator.disable(user,'synthetic-browser-operator');console.log(JSON.stringify({disabled:true}));}
   if(command==='counts')console.log(JSON.stringify({audit:(await db.admin.query('SELECT action,count(*)::int n FROM workspace.authentication_audit GROUP BY action ORDER BY action')).rows}));
  }catch{console.log(JSON.stringify({controlFailed:true}));}
 });
}catch{await stop();}
