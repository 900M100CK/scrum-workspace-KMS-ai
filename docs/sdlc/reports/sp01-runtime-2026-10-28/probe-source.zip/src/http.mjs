import Fastify from 'fastify';
import cookie from '@fastify/cookie';
import {randomBytes,createHash,scrypt,timingSafeEqual} from 'node:crypto';
import {promisify} from 'node:util';
import {loadContractSchemas} from '../../../../scripts/contract-schemas.mjs';
import {SYNTH} from './synthetic.mjs';
const kdf=promisify(scrypt);
const contracts=await loadContractSchemas('workspace');
const {Login,Session,Error:ErrorSchema}=contracts.api.components.schemas;
export const credentials=Object.freeze({username:'spike_user_a',password:'synthetic-only-lab-password'});
const salt=randomBytes(16);
const passwordHash=await kdf(credentials.password,salt,SYNTH.kdf.keylen,SYNTH.kdf);
const hash=token=>createHash('sha256').update(token).digest('hex');
export async function buildHttpProbe({baseline=false,tls,logStream,checkOutput=false,persist}={}){
 const app=Fastify({bodyLimit:SYNTH.bodyLimit,logger:logStream?{level:'info',stream:logStream,redact:['req.headers.cookie','req.body.password','res.headers["set-cookie"]']}:false,...(tls?{https:tls}:{}),...(!baseline?{ajv:{customOptions:{removeAdditional:false,coerceTypes:false,useDefaults:false}}}:{})});
 const sessions=new Map();const observations={input:[],output:[]};let unavailable=false;
 await app.register(cookie);
 if(!baseline)app.setValidatorCompiler(({schema})=>{
  let validate;
  if(schema===Login)validate=contracts.validators.get('Login');
  else throw new Error('Unexpected request schema in isolated HTTP probe');
  function wrapped(value){const before=structuredClone(value);const ok=validate(value);observations.input.push({before,after:structuredClone(value),ok});wrapped.errors=validate.errors;return ok;}
  return wrapped;
 });
 app.setErrorHandler((error,_req,reply)=>{const status=error.statusCode&&error.statusCode>=400&&error.statusCode<600?error.statusCode:500;reply.code(status).send({code:status===400?'validation_failed':'access_unavailable',message:status===400?'Invalid request':'Request unavailable',run_id:null});});
 app.addHook('onRequest',async(req,reply)=>{
  reply.header('Cache-Control','no-store');
  if(['POST','DELETE'].includes(req.method)&&(req.headers.origin!==SYNTH.origin||req.headers['x-sacw-request']!=='1'))return reply.code(403).send({code:'forbidden',message:'Request unavailable',run_id:null});
 });
 if(checkOutput)app.addHook('preSerialization',async(_req,reply,payload)=>{if(reply.statusCode===200&&payload?.user_id&&!contracts.validators.get('Session')(payload)){const error=new Error('Invalid synthetic response');error.statusCode=500;throw error;}return payload;});
 app.post('/session',{schema:{body:Login,response:{200:Session,400:ErrorSchema,401:ErrorSchema,403:ErrorSchema,503:ErrorSchema}}},async(req,reply)=>{
  const derived=await kdf(req.body.password,salt,SYNTH.kdf.keylen,SYNTH.kdf);
  const match=timingSafeEqual(derived,passwordHash);
  if(req.body.username!==credentials.username||!match)return reply.code(401).send({code:'authentication_required',message:'Invalid credentials',run_id:null});
  if(unavailable)return reply.code(503).send({code:'access_unavailable',message:'Request unavailable',run_id:null});
  const token=randomBytes(SYNTH.tokenBytes).toString('base64url');
  await persist?.(token);
  const data={user_id:'synthetic-a',expires_at:'2030-01-01T00:00:00Z'};sessions.set(hash(token),data);
  reply.setCookie('__Host-sacw-spike',token,{httpOnly:true,secure:true,sameSite:'strict',path:'/',maxAge:SYNTH.idleSeconds});
  return data;
 });
 app.get('/session',{schema:{response:{200:Session,401:ErrorSchema,503:ErrorSchema}}},async(req,reply)=>{
  if(unavailable)return reply.code(503).send({code:'access_unavailable',message:'Request unavailable',run_id:null});
  const token=req.cookies['__Host-sacw-spike'];const data=token&&sessions.get(hash(token));
  if(!data)return reply.code(401).send({code:'authentication_required',message:'No valid session',run_id:null});
  return data;
 });
 app.delete('/session',async(req,reply)=>{if(unavailable)return reply.code(503).send({code:'access_unavailable',message:'Request unavailable',run_id:null});const token=req.cookies['__Host-sacw-spike'];if(token)sessions.delete(hash(token));reply.clearCookie('__Host-sacw-spike',{httpOnly:true,secure:true,sameSite:'strict',path:'/'});return reply.code(204).send();});
 app.get('/__probe/output',async()=>({user_id:'synthetic-a',expires_at:'2030-01-01T00:00:00Z',token:'synthetic-output-canary',password_hash:'synthetic-hash-canary'}));
 app.get('/__probe/malformed',async()=>({user_id:'synthetic-a',expires_at:'invalid-date'}));
 app.get('/__probe/projected',{schema:{response:{200:Session}}},async()=>({user_id:'synthetic-a',expires_at:'2030-01-01T00:00:00Z',token:'synthetic-output-canary',password_hash:'synthetic-hash-canary'}));
 // Only registered probe routes execute: no application handler is imported or adopted.
 app.decorate('spike',{observations,sessions,setUnavailable(value){unavailable=value;}});
 await app.ready();return app;
}
export const stateHeaders={origin:SYNTH.origin,'x-sacw-request':'1'};
