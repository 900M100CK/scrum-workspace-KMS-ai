import Fastify from 'fastify';
import cookie from '@fastify/cookie';
const app = Fastify({ ajv: { customOptions: { removeAdditional: false, coerceTypes: false, useDefaults: false } } });
await app.register(cookie);
app.get('/toolchain', async () => ({ healthy: true }));
await app.ready();
const result = await app.inject('/toolchain');
if (result.statusCode !== 200) throw new Error('Toolchain startup failed');
await app.close();
