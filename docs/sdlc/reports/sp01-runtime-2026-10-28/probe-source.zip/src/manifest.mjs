import {readFile,writeFile,mkdir,readdir} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
export const runtime=fileURLToPath(new URL('..',import.meta.url));
export const root=path.resolve(runtime,'../../..');
export const digest=bytes=>createHash('sha256').update(bytes).digest('hex');
async function sourceFiles(dir){let out=[];for(const entry of await readdir(dir,{withFileTypes:true})){if(['node_modules','results','tls'].includes(entry.name))continue;const p=path.join(dir,entry.name);if(entry.isDirectory())out.push(...await sourceFiles(p));else if(/\.(mjs|ts|json|sql|yaml)$/.test(p))out.push(p);}return out;}
export async function capture(){
 const inputs=[...await sourceFiles(runtime),...['contracts/openapi/workspace.openapi.json','scripts/contract-schemas.mjs','package.json','package-lock.json','SP-01.1-spike-brief.md'].map(p=>path.join(root,p))].sort();
 const files={};for(const p of inputs)files[path.relative(root,p).replaceAll('\\','/')]=digest(await readFile(p));
 const git=(args,encoding='utf8')=>execFileSync('git',args,{cwd:root,encoding});
 const scope=['.tmp/sp01-foundation-2026-10-27/runtime','contracts/openapi/workspace.openapi.json','scripts/contract-schemas.mjs','package.json','package-lock.json','SP-01.1-spike-brief.md'];
 const installed={};for(const name of ['fastify','@fastify/cookie','pg','ajv','ajv-formats','fast-json-stringify','@fastify/ajv-compiler','@fastify/fast-json-stringify-compiler'])installed[name]=JSON.parse(await readFile(path.join(runtime,'node_modules',name,'package.json'),'utf8')).version;
 const rootInstalled={};for(const name of ['typescript','ajv','ajv-formats']){const p=path.join(root,'node_modules',name,'package.json');rootInstalled[name]=JSON.parse(await readFile(p,'utf8')).version;files[path.relative(root,p).replaceAll('\\','/')]=digest(await readFile(p));}
 return {head:git(['rev-parse','HEAD']).trim(),branch:git(['branch','--show-current']).trim(),submodules:git(['submodule','status']),scopedDiffSha256:digest(git(['diff','--binary','HEAD','--',...scope],null)),dirtyPaths:git(['status','--porcelain=v1','-z','--',...scope]).split('\0').filter(Boolean),files,installed,rootInstalled,node:{version:process.version,versions:process.versions,platform:process.platform,arch:process.arch}};
}
export const sameInputs=(a,b)=>JSON.stringify(a.files)===JSON.stringify(b.files)&&JSON.stringify(a.installed)===JSON.stringify(b.installed);
export async function save(dir,name,body){await mkdir(dir,{recursive:true});const p=path.join(dir,name);await writeFile(p,JSON.stringify(body,null,2)+'\n');return {path:path.relative(root,p).replaceAll('\\','/'),sha256:digest(await readFile(p))};}
