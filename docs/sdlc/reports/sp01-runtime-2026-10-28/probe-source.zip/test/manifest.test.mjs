import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,writeFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {capture,sameInputs,save,digest} from '../src/manifest.mjs';
test('P02 captures actual ignored probe inputs and installed tuple without secrets or generated outputs',async()=>{
 const a=await capture(),b=await capture();assert(sameInputs(a,b));
 assert(Object.keys(a.files).some(p=>p.endsWith('/src/manifest.mjs')));
 assert(Object.keys(a.files).some(p=>p.endsWith('/test/manifest.test.mjs')));
 assert(Object.keys(a.files).every(p=>!p.includes('/results/')&&!p.includes('/tls/')&&!p.includes('/node_modules/')));
 assert.equal(a.installed.pg,'8.23.1');
 const changed=structuredClone(a);changed.files['synthetic-edit']=digest('changed');assert.equal(sameInputs(a,changed),false);
});
test('P02 before and after are distinct immutable-at-capture files, without self-digests',async()=>{
 const dir=await mkdtemp(path.join(tmpdir(),'sp01-manifest-'));
 try{const a=await capture();const first=await save(dir,'manifest-before.json',a);const second=await save(dir,'manifest-after.json',a);assert.notEqual(first.path,second.path);assert.equal(first.sha256,second.sha256);assert(!JSON.stringify(a).includes('manifest-before.json'));}finally{assert.equal(path.dirname(path.resolve(dir)),path.resolve(tmpdir()));assert(path.basename(dir).startsWith('sp01-manifest-'));await rm(dir,{recursive:true,force:true});}
});
