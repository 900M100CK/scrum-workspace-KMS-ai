CREATE TABLE IF NOT EXISTS probe_session (
 digest text PRIMARY KEY CHECK (digest ~ '^[a-f0-9]{64}$'),
 idle_at timestamptz NOT NULL,
 absolute_at timestamptz NOT NULL,
 revoked_at timestamptz,
 renewals bigint NOT NULL DEFAULT 0,
 CHECK (idle_at <= absolute_at)
);
CREATE TABLE IF NOT EXISTS probe_audit (detail text NOT NULL CHECK (detail <> 'reject'));
CREATE TABLE IF NOT EXISTS probe_clock_guard (
 singleton boolean PRIMARY KEY DEFAULT true CHECK (singleton),
 last_observed timestamptz,
 healthy boolean NOT NULL DEFAULT true
);
INSERT INTO probe_clock_guard(singleton) VALUES(true) ON CONFLICT DO NOTHING;
