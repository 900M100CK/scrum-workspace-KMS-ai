import pg from 'pg';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {writeFile,readFile} from 'node:fs/promises';
import {randomBytes,createHash} from 'node:crypto';
const exec=promisify(execFile);
export const image='pgvector/pgvector:0.8.2-pg17-bookworm@sha256:feb68f4f15446397d8cac7f4fe48fe4586de83160d1fc48b46283312d1a33966';
export const digestToken=t=>createHash('sha256').update(t).digest('hex');
export async function database(){
 const name=`sp01-probe-${randomBytes(6).toString('hex')}`,password=randomBytes(24).toString('hex');
 const env=new URL('../tls/'+name+'.env',import.meta.url);await writeFile(env,`POSTGRES_PASSWORD=${password}\nPOSTGRES_DB=spike\n`);
 await exec('docker',['run','--detach','--name',name,'--label','sacw.task=SP01-P04-P05','--env-file',env.pathname.replace(/^\/(\w:)/,'$1'),'--tmpfs','/var/lib/postgresql/data:rw','--publish','127.0.0.1::5432',image],{timeout:120000});
 let pool;
 try{
  const {stdout}=await exec('docker',['port',name,'5432/tcp']);const port=Number(stdout.trim().split(':').at(-1));
  const config={host:'127.0.0.1',port,user:'postgres',password,database:'spike',application_name:name,max:3,connectionTimeoutMillis:1200,idleTimeoutMillis:1000};
  pool=new pg.Pool(config);pool.on('error',()=>{});
  const deadline=Date.now()+30000;while(true){try{await pool.query('select 1');break;}catch(error){if(Date.now()>deadline)throw error;await new Promise(r=>setTimeout(r,200));}}
  const sql=await readFile(new URL('../sql/001_spike.sql',import.meta.url),'utf8');await pool.query(sql);
  return {pool,config,name,image,version:(await pool.query('select version()')).rows[0].version,sql,async close(){await pool.end();await exec('docker',['rm','--force',name]);}};
 }catch(error){if(pool)await pool.end();await exec('docker',['rm','--force',name]);throw error;}
}
export async function transaction(pool,work,{beforeRollback}={}){
 const client=await pool.connect();let discard=false;
 try{await client.query('BEGIN');await client.query("SET LOCAL statement_timeout='3000ms'");await client.query("SET LOCAL lock_timeout='2000ms'");const result=await work(client);await client.query('COMMIT');return result;}
 catch(error){try{await beforeRollback?.(client);await client.query('ROLLBACK');}catch{discard=true;}throw error;}
 finally{client.release(discard);}
}
export async function insertSession(pool,{token=randomBytes(32).toString('base64url'),idle=60000,absolute=300000,time=Date.now(),auditFail=false,insertFail=false}={}){
 await transaction(pool,async c=>{await c.query('INSERT INTO probe_session(digest,idle_at,absolute_at) VALUES($1,$2,$3)',[insertFail?'bad':digestToken(token),new Date(time+idle),new Date(time+absolute)]);await c.query('INSERT INTO probe_audit(detail) VALUES($1)',[auditFail?'reject':'created']);});return token;
}

