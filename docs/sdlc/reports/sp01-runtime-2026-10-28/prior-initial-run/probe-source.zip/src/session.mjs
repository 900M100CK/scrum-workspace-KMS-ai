import {transaction,digestToken,insertSession} from './database.mjs';
export const barrier=()=>{let resolve;const promise=new Promise(r=>{resolve=r;});return {promise,resolve};};
export class Repository {
 constructor(pool,{clock,idle=60000}={}){this.pool=pool;this.clock=clock;this.idle=idle;this.events=[];}
 async create(options){return insertSession(this.pool,options);}
 async act(token,{logout=false,renew=false,locked,started}={}){
  return transaction(this.pool,async c=>{
   const pid=(await c.query('select pg_backend_pid() pid')).rows[0].pid;started?.(pid);
   const row=(await c.query('select * from probe_session where digest=$1 for update',[digestToken(token)])).rows[0];
   this.events.push({event:'locked',pid});await locked?.();
   const now=this.clock?await this.clock():(await c.query('select clock_timestamp() now')).rows[0].now.getTime();
   this.events.push({event:'decision',pid,time:now});
   if(logout){if(row&&!row.revoked_at)await c.query('update probe_session set revoked_at=$2 where digest=$1',[digestToken(token),new Date(now)]);return {status:204};}
   if(!row||row.revoked_at||now>=row.idle_at.getTime()||now>=row.absolute_at.getTime())return {status:401};
   let expiry=row.idle_at.getTime();
   if(renew){expiry=Math.min(row.absolute_at.getTime(),Math.max(expiry,now+this.idle));await c.query('update probe_session set idle_at=$2, renewals=renewals+1 where digest=$1',[digestToken(token),new Date(expiry)]);}
   return {status:200,expires_at:new Date(expiry).toISOString()};
  }).then(result=>{this.events.push({event:'commit-ack',status:result.status});return result;});
 }
}
export async function confirmedWaiting(pool,pid){
 const deadline=Date.now()+1500;
 while(Date.now()<deadline){const row=(await pool.query('select wait_event_type from pg_stat_activity where pid=$1',[pid])).rows[0];if(row?.wait_event_type==='Lock')return;await new Promise(r=>setTimeout(r,10));}
 throw new Error('Contender did not reach an observed PostgreSQL lock wait');
}
