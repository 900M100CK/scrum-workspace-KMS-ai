import {transaction,digestToken,insertSession} from './database.mjs';
import {randomBytes} from 'node:crypto';
export const barrier=()=>{let resolve;const promise=new Promise(r=>{resolve=r;});return {promise,resolve};};
export class Repository {
 constructor(pool,{clock,idle=60000,guard=false}={}){this.pool=pool;this.clock=clock;this.idle=idle;this.guard=guard;this.events=[];}
 async sample(c){return this.clock?await this.clock():(await c.query('select clock_timestamp() now')).rows[0].now.getTime();}
 async observe(c){
  const row=(await c.query('select * from probe_clock_guard where singleton=true for update')).rows[0];
  if(!row)throw new Error('Missing clock guard; fail closed');
  const now=await this.sample(c),last=row.last_observed?.getTime();
  const healthy=row.healthy&&(last===undefined||now>=last);
  await c.query('update probe_clock_guard set last_observed=$1,healthy=$2 where singleton=true',[new Date(Math.max(last??now,now)),healthy]);
  return {now,healthy,last:last??now};
 }
 async create(options){
  if(!this.guard)return insertSession(this.pool,options);
  const result=await transaction(this.pool,async c=>{const state=await this.observe(c);if(!state.healthy)return null;const token=randomBytes(32).toString('base64url');await c.query('insert into probe_session(digest,idle_at,absolute_at) values($1,$2,$3)',[digestToken(token),new Date(state.now+this.idle),new Date(state.now+300000)]);await c.query("insert into probe_audit(detail) values('created')");return token;});
  if(result===null)throw new Error('Clock unhealthy; issuance withheld');return result;
 }
 async act(token,{logout=false,renew=false,locked,started}={}){
  return transaction(this.pool,async c=>{
   const pid=(await c.query('select pg_backend_pid() pid')).rows[0].pid;started?.(pid);
   const row=(await c.query('select * from probe_session where digest=$1 for update',[digestToken(token)])).rows[0];
   this.events.push({event:'locked',pid});await locked?.();
   const state=this.guard?await this.observe(c):{now:await this.sample(c),healthy:true};
   const now=state.now;
   this.events.push({event:'decision',pid,time:now});
   if(logout){if(row&&!row.revoked_at)await c.query('update probe_session set revoked_at=$2 where digest=$1',[digestToken(token),new Date(state.healthy?now:state.last)]);return {status:204};}
   if(!state.healthy)return {status:503};
   if(!row||row.revoked_at||now>=row.idle_at.getTime()||now>=row.absolute_at.getTime())return {status:401};
   let expiry=row.idle_at.getTime();
   if(renew){expiry=Math.min(row.absolute_at.getTime(),Math.max(expiry,now+this.idle));await c.query('update probe_session set idle_at=$2, renewals=renewals+1 where digest=$1',[digestToken(token),new Date(expiry)]);}
   return {status:200,expires_at:new Date(expiry).toISOString()};
  }).then(result=>{this.events.push({event:'commit-ack',status:result.status});return result;});
 }
}
export async function confirmedWaiting(pool,pid){
 const deadline=Date.now()+1500;
 while(Date.now()<deadline){const row=(await pool.query('select wait_event_type from pg_stat_activity where pid=$1',[pid])).rows[0];if(row?.wait_event_type==='Lock')return;await new Promise(r=>setTimeout(r,10));}
 throw new Error('Contender did not reach an observed PostgreSQL lock wait');
}
