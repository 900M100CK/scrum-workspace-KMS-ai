import cookie from '@fastify/cookie';
import type {FastifyInstance,FastifyRequest} from 'fastify';
import type {WorkspaceSessionStore,StoredSession} from './store.ts';
import {ScryptVerifier} from './kdf.ts';
import type {PasswordVerifier} from './ports.ts';
import {sessionSchemas,sessionValidators} from './schemas.ts';

export const SESSION_COOKIE='__Host-sacw-session';
type Store=Pick<WorkspaceSessionStore,'credential'|'establish'|'inspect'>;
type Verifier=PasswordVerifier&{readonly dummyCredential:string};
export interface SessionHttpOptions {store?:Store;verifier?:Verifier;origin?:string}
export interface SessionRequest extends FastifyRequest {sessionContext:StoredSession|null}
const errorBody=(code:string,message:string)=>({code,message,run_id:null});
const unavailable=()=>errorBody('access_unavailable','Session unavailable');
const unauthenticated=()=>errorBody('authentication_required','Authentication required');

export function sessionOrigin(value:string):string{
 let url:URL;try{url=new URL(value);}catch{throw new Error('Session origin must be an HTTPS origin');}
 if(url.protocol!=='https:'||url.username||url.password||url.pathname!=='/'||url.search||url.hash)throw new Error('Session origin must be an HTTPS origin');
 return url.origin;
}
function bearer(request:FastifyRequest):string|null{
 const fields=(request.headers.cookie??'').split(';').map(field=>field.trim().split('=')[0]);
 if(fields.filter(name=>name===SESSION_COOKIE).length!==1)return null;
 return request.cookies[SESSION_COOKIE]??null;
}
export async function registerSessionHttp(app:FastifyInstance,options:SessionHttpOptions):Promise<void>{
 const origin=options.origin===undefined?null:sessionOrigin(options.origin);
 const verifier=options.verifier??new ScryptVerifier();
 await app.register(cookie);
 // Cookie plugin flushes its queue in onSend; remove its header after that on unsuccessful login.
 app.addHook('onSend',async(request,reply,payload)=>{
  if(request.method==='POST'&&request.routeOptions.url==='/session'&&reply.statusCode!==200)reply.removeHeader('set-cookie');
  return payload;
 });
 app.decorateRequest('sessionContext',null);
 // Validate the final object after preSerialization hooks, without silent field projection.
 const serializerCompiler:import('fastify').FastifySerializerCompiler<unknown>=({httpStatus})=>payload=>{
  const validator=String(httpStatus)==='200'?sessionValidators.Session:sessionValidators.Error;
  if(!validator!(payload))throw new Error('Invalid session output');return JSON.stringify(payload);
 };
 const responses={200:sessionSchemas.Session,400:sessionSchemas.Error,401:sessionSchemas.Error,403:sessionSchemas.Error,413:sessionSchemas.Error,415:sessionSchemas.Error,503:sessionSchemas.Error};
 // Explicit compiler applies only to this route body; future routes keep their own contract policy.
 app.post<{Body:{username:string;password:string}}>('/session',{
  bodyLimit:8192,
  onRequest:async(request,reply)=>{
   reply.header('Cache-Control','no-store');
   if(!origin||!options.store)return reply.code(503).send(unavailable());
   if(request.headers.origin!==origin||request.headers['x-sacw-request']!=='1')return reply.code(403).send(errorBody('forbidden','Request denied'));
  },
  schema:{body:sessionSchemas.Login,response:responses},
  validatorCompiler:()=>sessionValidators.Login!,
  serializerCompiler,
 },async(request,reply)=>{
  try{
   const {username,password}=request.body;
   // PostgreSQL text cannot represent NUL; this remains an unknown identity, not a normalization rule.
   const account=username.includes('\0')?null:await options.store!.credential(username);
   const verified=await verifier.verify(password,account?.credential??verifier.dummyCredential);
   if(!account||!verified||account.disabled)return reply.code(401).send(unauthenticated());
   const issued=await options.store!.establish(account.userId,account.revision,request.id);
   if(issued.kind==='unauthenticated')return reply.code(401).send(unauthenticated());
   if(issued.kind!=='created')return reply.code(503).send(unavailable());
   reply.setCookie(SESSION_COOKIE,issued.token,{httpOnly:true,secure:true,sameSite:'strict',path:'/',expires:new Date(issued.session.expiresAt)});
   (request as SessionRequest).sessionContext=issued.session;
   return {user_id:issued.session.userId,expires_at:issued.session.expiresAt};
  }catch{reply.removeHeader('set-cookie');return reply.code(503).send(unavailable());}
 });
 app.get('/session',{
  schema:{response:{200:sessionSchemas.Session,401:sessionSchemas.Error,503:sessionSchemas.Error}},
  serializerCompiler,
  onRequest:async(_request,reply)=>{reply.header('Cache-Control','no-store');},
 },async(request,reply)=>{
  if(!options.store||!origin)return reply.code(503).send(unavailable());
  const token=bearer(request);if(!token)return reply.code(401).send(unauthenticated());
  try{
   const result=await options.store.inspect(token);
   if(result.kind==='unauthenticated')return reply.code(401).send(unauthenticated());
   if(result.kind!=='authenticated')return reply.code(503).send(unavailable());
   (request as SessionRequest).sessionContext=result.session;
   return {user_id:result.session.userId,expires_at:result.session.expiresAt};
  }catch{return reply.code(503).send(unavailable());}
 });
}
